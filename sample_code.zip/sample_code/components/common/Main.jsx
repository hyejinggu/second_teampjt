import Slide from '../main/Slide';

const Main = () => {
    return (
        <div>
            <Slide />
        </div>
    )
}

export default Main;