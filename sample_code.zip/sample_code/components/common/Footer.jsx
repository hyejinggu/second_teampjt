const Footer = () => {
    return (
        <div>
            <p>Footer</p>
        </div>
    )
}

export default Footer;