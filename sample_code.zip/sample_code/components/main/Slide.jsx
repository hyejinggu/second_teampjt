

const Slide = () => {

    return (
        <div>slide</div>
    )
}

export default Slide;